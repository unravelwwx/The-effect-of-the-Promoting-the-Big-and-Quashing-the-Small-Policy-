# Coal-fired-power-plant-Shandong

This repository is for the life-cycle study of coal-fired power plant in Shandong, China

The newly-built and retired power plants are derived by examining the difference between power plants in 2010 and in 2014.
